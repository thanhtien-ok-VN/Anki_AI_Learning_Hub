GENERIC_GRADER_PROMPT = """You are a language teacher grading a student's answer.

Learning language: {learn_lang}
Game mode: {gamemode}
Student's level: {level}
Question: {question}
Expected answer: {expected}
Student's answer: {user_answer}
Hint level used by student: {hint_level} (Level 0=No hint, Level 1=Grammar, Level 2=First letter/Meaning, Level 3=Answer revealed)

Grade the answer considering the student's level and hint usage. Provide:
1. Whether it's correct (true/false)
2. A score from 0.0 to 1.0
3. Brief explanation of errors (if wrong) or confirmation (if correct)
4. A helpful suggestion for improvement

Respond entirely in {feedback_lang}. Respond in JSON format:
{{
    "correct": true/false,
    "score": 0.0-1.0,
    "explanation": "string",
    "suggestion": "string"
}}
"""

FILL_BLANK_GRADER = """You are a language teacher grading a fill-in-the-blank exercise.

Learning language: {learn_lang}
Student's level: {level}
Target word: {target_word}
Meaning: {meaning}
Question: {question}
Expected answer: {expected}
Student's answer: {user_answer}
Hint level used by student: {hint_level} (Level 0=No hint, Level 1=Grammar, Level 2=First letter/Meaning, Level 3=Answer revealed)

Explain why the correct answer is right or wrong. Include:
- Semantic meaning of the correct word in context
- Grammar rule involved
- Why the other options are incorrect (consider the option types and semantic/grammatical context)

Respond entirely in {feedback_lang}. Respond in JSON:
{{
    "correct": true/false,
    "score": 0-10,
    "semantic": "string",
    "grammar": "string",
    "vocabulary_relation": "string"
}}
"""

TRANSLATION_GRADER = """You are a professional language teacher grading a translation exercise.

Source Language: {source_lang}
Target Language: {learn_lang}
Source Sentence: {source_sentence}
Expected Translation: {reference_translation}
Student's Translation: {user_target}

Student's level: {level}

Task:
Evaluate the student's translation, identify specific errors, and provide grading and suggestions.
For each error, you MUST provide 5 fields: name, wrong, reason, suggestion, and why.
MANDATORY LANGUAGE RULE: All reference translations and suggested answers MUST be written in {learn_lang}. All error explanations, reasons, and fix suggestions MUST be written entirely in {feedback_lang}.

Respond in JSON matching the exact schema below:
{{
    "correct": true/false,
    "score": 0-10,
    "level": "Pass" or "Needs improvement",
    "errors": [
        {{
            "name": "Error category (e.g., Verb Tense, Word Choice, Grammar)",
            "wrong": "The incorrect part of the student's translation",
            "reason": "Why it is incorrect",
            "suggestion": "How to fix it",
            "why": "Why this correction is better"
        }}
    ]
}}
"""

UNSCRAMBLE_GRADER = """You are a language teacher grading a sentence unscramble exercise.

Correct sentence: {correct_sentence}
Student's sentence: {user_sentence}

Consider level: {level}

If correct, provide a short praise and a brief grammar highlight (1-2 sentences).
If incorrect, identify the specific out of order words and explain the correct word order rule.

Respond entirely in {feedback_lang}. Respond in JSON matching the exact schema below:
{{
    "correct": true/false,
    "score": 0-10,
    "praise": "A short praise (only if correct)",
    "highlight": "Brief grammar/vocab highlight, 1-2 sentences (only if correct)",
    "error_position": "Specific words that are wrong or misplaced (only if incorrect)",
    "rule": "The word order grammar rule explaining why the student is wrong and how to fix it (only if incorrect)"
}}
"""

TRANSFORM_GRADER = """You are a professional language teacher grading a sentence transformation exercise.

Instruction/Prompt: {prompt}
Original Sentence: {original}
Expected Answer: {expected_answer}
Student's Answer: {user_answer}
Student's level: {level}
Hint level used by student: {hint_level} (Level 0=No hint, Level 1=Grammar, Level 2=First letter/Meaning, Level 3=Answer revealed)

Task:
Evaluate the student's transformation answer, identify specific errors (e.g., Passive Voice Structure, Verb Tense, Word Order, Forbidden Word), and provide granular grading and suggestions.
For each error identified, you MUST provide 5 fields: name, wrong, reason, suggestion, and why.
MANDATORY LANGUAGE RULE: All corrected sentences and suggested answers MUST be written in {learn_lang}. All error explanations, reasons, and fix suggestions MUST be written entirely in {feedback_lang}.

Respond in JSON matching the exact schema below:
{{
    "correct": true/false,
    "score": 0-10,
    "level": "Pass" or "Needs improvement",
    "errors": [
        {{
            "name": "Error category (e.g., Passive Voice Structure, Verb Tense, Word Choice)",
            "wrong": "The incorrect part of the student's answer",
            "reason": "Why it is incorrect under the target grammar rule",
            "suggestion": "How to fix it",
            "why": "Why this correction makes the sentence correct"
        }}
    ],
    "suggested_answers": {{
        "common": "A natural, standard correct sentence transformation",
        "advanced": "A more advanced, sophisticated transformation with richer vocabulary"
    }},
    "grammar_rule": "The core grammar rule being tested"
}}
"""

TABOO_GRADER = """You are a professional language teacher judging a Taboo word-guessing game.

Target Word: {target_word} (Meaning: {meaning})
Taboo Words (Forbidden): {taboo_words}
Sample Acceptable Guess Phrases: {sample_acceptable_phrases}
Sample Forbidden/Invalid Phrases: {sample_forbidden_phrases}
Student's Guess(es): {user_input} (which may contain multiple terms separated by commas)

Task:
1. Split the student's guesses by commas and evaluate each guessed word/phrase individually.
2. For each guess, check if it contains any forbidden/Taboo words or variations of them. If yes, it is rejected (accepted=false), and explain which taboo word was violated.
3. Otherwise, check if it matches or is semantically close/synonymous to the Target Word. If yes, it is accepted (accepted=true) with a positive explanation. If no, it is rejected (accepted=false) with a brief explanation why it is incorrect.
4. Set "correct": true if AT LEAST ONE guess is accepted (accepted=true). Otherwise, set "correct": false.
5. Explain all feedback and reasons in {feedback_lang}.

Respond in JSON matching the exact schema below:
{{
    "correct": true/false,
    "score": 0-10,
    "ai_analysis": "Overall pedagogical feedback in {feedback_lang}",
    "word_definition": "Clear definition of the target word in {learn_lang} with {feedback_lang} translation",
    "guess_feedback": [
        {{
            "guess": "The student's exact guess phrase",
            "accepted": true/false,
            "reason": "Why this guess was accepted or rejected (in {feedback_lang})"
        }}
    ]
}}
"""


GRADER_PROMPTS = {
    "fill_blank": FILL_BLANK_GRADER,
    "translation": TRANSLATION_GRADER,
    "unscramble": UNSCRAMBLE_GRADER,
    "sentence_transform": TRANSFORM_GRADER,
    "taboo": TABOO_GRADER,
}


def get_grader_prompt(gamemode: str, **kwargs) -> str:
    if gamemode in GRADER_PROMPTS:
        return GRADER_PROMPTS[gamemode].format(**kwargs)
    return GENERIC_GRADER_PROMPT.format(**kwargs)
